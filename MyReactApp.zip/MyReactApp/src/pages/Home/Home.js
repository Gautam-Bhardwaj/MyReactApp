import React, { Component } from 'react';
import {
  StyleSheet,
  ActivityIndicator,
  ScrollView,
  View,
} from 'react-native';
import Grid from '../../components/Grid'

class Home extends Component
{
    state = {
        users:[],
        loading:true
    };

    componentDidMount = () =>
    {
        //Get Users
        this.getUsers();
    }

    getUsers = () =>
    {
        fetch("https://randomuser.me/api/?results=8").then((response)=>response.json()).then(response => {this.setState({users:response.results, loading: false});});
    }

    render()
    {
        return(
            <ScrollView noSpacer={false} noScroll={true} style={styles.container} >
                {this.state.loading?
                <ActivityIndicator style={[styles.centering, styles.gray]} color="#ff8179" size="large" >
                </ActivityIndicator>
                : <View>
                   <Grid items={this.state.users}/>
                    </View>
                }
            </ScrollView>
        );
    }
}

var styles = StyleSheet.create({
    container: {
      backgroundColor: "whitesmoke",
      width: '75%',
    },
    centering: {
      alignItems: "center",
      justifyContent: "center",
      padding: 8,
    },
  });

export default Home;