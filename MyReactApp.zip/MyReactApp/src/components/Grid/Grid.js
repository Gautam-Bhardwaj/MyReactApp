import React from "react";
import { SwipeableFlatList } from "react-native";
import GridItem from "../GridItem";
import GridActions from "./GridActions";

const Grid = ({ items }) => {
  return (
    <SwipeableFlatList
      data={items}
      bounceFirstRowOnMount={true}
      maxSwipeDistance={160}
      renderItem={GridItem}
      renderQuickActions={GridActions}
    />
  );
};

export default Grid;