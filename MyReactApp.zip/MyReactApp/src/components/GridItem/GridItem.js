  import React from "react";
  import { View, Image, Text, StyleSheet } from "react-native";

  const GridItem = ({ item: gridItem }) => {
    return (
      <View style={styles.row}>
        <Image style={styles.rowIcon} source={gridItem.picture.medium} />
        <View style={styles.rowData}>
          <Text style={styles.rowDataText}>{`${gridItem.name.title} ${
            gridItem.name.first
          } ${gridItem.name.last}`}</Text>
          <Text style={styles.rowDataSubText}>{gridItem.email}</Text>
        </View>
      </View>
    );
  };

  const styles = StyleSheet.create({
    row: {
      flexDirection: "row",
      justifyContent: "center",
      alignItems: "center",
      padding: 15,
      marginBottom: 5,
      backgroundColor: "white",
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: "rgba(0,0,0,0.1)",
      width: '100%',
    },
    rowIcon: {
      width: 64,
      height: 64,
      marginRight: 20,
      borderRadius: "50%",
      boxShadow: "0 1px 2px 0 rgba(0,0,0,0.1)"
    },
    rowData: {
      flex: 1
    },
    rowDataText: {
      fontSize: 15,
      textTransform: "capitalize",
      color: "#4b4b4b"
    },
    rowDataSubText: {
      fontSize: 13,
      opacity: 0.8,
      color: "#a8a689",
      marginTop: 4
    }
  });

  export default GridItem;