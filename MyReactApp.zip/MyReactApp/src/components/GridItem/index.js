import GridItem from './GridItem';

export default GridItem;
